package testCases;

import org.testng.annotations.Test;

import pageObjects.LoanCalculatorPage;
import testBase.BaseClass;
import utilities.AddFluentWait;
import utilities.Assertions;

public class TC_3_29_LoanTenureCalculator_ValidatingEMISlider extends BaseClass{
	//Creating an instance of the AddFluentWait utility
	AddFluentWait wait = new AddFluentWait();

	//Creating an instance of the Assertions utility
	Assertions myAssert = new Assertions();

	@Test
	public void validatingEMISlider() {

		logger.info("**** TC_3_29_LoanTenureCalculator_ValidatingEMISlider Started ****");
		try {
			//Creating an instance of the PageObject
			LoanCalculatorPage obj1 = new LoanCalculatorPage(driver);

			//Waiting for the main menu to load
			wait.waitForMainMenu(driver);

			//Navigating to the respective page
			obj1.navigatorForLoanTenureCalc();

			//Waiting for all the fields to be visible
			wait.waitForTheTextBoxAndSlider(driver);

			//Validating if EMI Slider is visible And Enabled
			if(obj1.getEMISlider().isDisplayed() && obj1.getEMISlider().isEnabled()) {
				myAssert.pass();
			}
			else {
				logger.error("TC_3_29 got failed, EMI Slider is not visible or Not Enabled.");
				System.out.println("TC_3_29 got failed, EMI Slider is not visible or Not ENabled.");
				myAssert.fail();
			}

			
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
			System.out.println("TC_3_29 got failed, validation of EMI Slider was unsuccessful");

			logger.error("TC_3_29 got failed, validation of EMI Slider was not successful");
			myAssert.fail();
		}

		logger.info("**** TC_3_29_LoanTenureCalculator_ValidatingEMISlider Ended ****");
	}
}
